"""Practical 5: Bernoulli, Multinomial, and Gaussian Naive Bayes."""

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import BernoulliNB, MultinomialNB, GaussianNB


# 1) Bernoulli Naive Bayes: each feature is either 0 (no) or 1 (yes).
# Columns: studied, attended class, submitted homework.
X_binary = np.array([
    [1, 1, 1],
    [1, 1, 0],
    [1, 0, 1],
    [0, 1, 0],
    [0, 0, 0],
    [0, 1, 1],
])
passed = np.array([1, 1, 1, 0, 0, 0])

bernoulli_model = BernoulliNB()
bernoulli_model.fit(X_binary, passed)
new_student = [[1, 1, 0]]
print("BernoulliNB predicted pass (1=yes):", bernoulli_model.predict(new_student)[0])

# 2) Multinomial Naive Bayes: count how many times each word appears.
documents = [
    "good fun movie",
    "good movie",
    "fun enjoyable movie",
    "bad boring movie",
    "boring bad film",
    "bad film",
]
sentiment = ["positive", "positive", "positive", "negative", "negative", "negative"]

vectorizer = CountVectorizer()
word_counts = vectorizer.fit_transform(documents)
multinomial_model = MultinomialNB()
multinomial_model.fit(word_counts, sentiment)
new_review = vectorizer.transform(["good fun"])
print("MultinomialNB predicted review:", multinomial_model.predict(new_review)[0])

# 3) Gaussian Naive Bayes: features are continuous numbers.
# This tiny example uses two measurements and two flower classes.
X_measurements = np.array([
    [1.0, 1.1], [1.2, 0.9], [0.8, 1.0], [1.1, 1.2],
    [4.0, 4.1], [4.2, 3.9], [3.8, 4.0], [4.1, 4.2],
])
flower_type = np.array(["small"] * 4 + ["large"] * 4)

gaussian_model = GaussianNB()
gaussian_model.fit(X_measurements, flower_type)
new_measurement = [[1.0, 0.95]]
print("GaussianNB predicted flower type:", gaussian_model.predict(new_measurement)[0])
