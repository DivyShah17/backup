"""Practical 1: a tiny tour of Python, NumPy, Pandas, Matplotlib, and sklearn."""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


# Plain Python variables and a list.
student = "Asha"
marks = [72, 85, 91]
print("Student:", student)
print("Average marks:", sum(marks) / len(marks))

# NumPy stores numbers in arrays and can do calculations on all values at once.
hours = np.array([1, 2, 3, 4, 5]).reshape(-1, 1)
scores = np.array([35, 42, 50, 58, 65])
print("NumPy hours:", hours.ravel())
print("Scores plus 5:", scores + 5)

# Pandas makes a labelled table (a DataFrame).
table = pd.DataFrame({"hours_studied": hours.ravel(), "score": scores})
print("\nPandas table:")
print(table)

# Matplotlib draws a basic scatter plot.
plt.scatter(table["hours_studied"], table["score"])
plt.xlabel("Hours studied")
plt.ylabel("Score")
plt.title("Study hours and scores")
plt.show()

# sklearn fits a simple model and predicts a score for 6 study hours.
model = LinearRegression()
model.fit(hours, scores)
predicted_score = model.predict([[6]])
print("Predicted score for 6 hours:", round(predicted_score[0], 1))
