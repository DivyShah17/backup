"""Practical 8: train an AND gate with the Perceptron Learning Algorithm."""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# The four rows of the truth table are the training examples.
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 0, 0, 1])

weights = np.zeros(2)
bias = 0.0
learning_rate = 0.1


def predict_one(inputs):
    """A perceptron outputs 1 when weighted sum plus bias is >= 0."""
    total = np.dot(inputs, weights) + bias
    return 1 if total >= 0 else 0


# Repeatedly correct a wrong prediction by nudging weights and bias.
for epoch in range(20):
    mistakes = 0

    for inputs, target in zip(X, y):
        prediction = predict_one(inputs)
        error = target - prediction

        if error != 0:
            weights[:] = weights + learning_rate * error * inputs
            bias = bias + learning_rate * error
            mistakes += 1

    if mistakes == 0:
        print("Training stopped after epoch", epoch + 1)
        break

predictions = np.array([predict_one(row) for row in X])
answer_table = pd.DataFrame({
    "Input 1": X[:, 0],
    "Input 2": X[:, 1],
    "Expected AND": y,
    "Perceptron output": predictions,
})

print("\nLearned weights:", weights)
print("Learned bias:", bias)
print("\nTruth table:")
print(answer_table)

# Plot the points and, when possible, the learned straight decision boundary.
plt.scatter(X[:, 0], X[:, 1], c=y, cmap="coolwarm", s=120)
if weights[1] != 0:
    x_values = np.linspace(-0.2, 1.2, 100)
    y_values = -(weights[0] * x_values + bias) / weights[1]
    plt.plot(x_values, y_values, color="black", label="Decision boundary")
plt.xticks([0, 1])
plt.yticks([0, 1])
plt.xlabel("Input 1")
plt.ylabel("Input 2")
plt.title("AND gate trained with one perceptron")
plt.legend()
plt.show()
