"""Practical 6: compare entropy/Gini trees and a few tree parameters."""

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import accuracy_score


iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data,
    iris.target,
    test_size=0.25,
    random_state=42,
    stratify=iris.target,
)

# Entropy is commonly taught with ID3; Gini is commonly taught with CART.
for split_rule in ["entropy", "gini"]:
    model = DecisionTreeClassifier(criterion=split_rule, random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"criterion={split_rule}, accuracy={accuracy_score(y_test, predictions):.2f}")

# Change one setting at a time and see its effect on this same train/test split.
settings = [
    {"label": "default", "options": {}},
    {"label": "max_depth=2", "options": {"max_depth": 2}},
    {"label": "max_depth=5", "options": {"max_depth": 5}},
    {"label": "min_samples_split=10", "options": {"min_samples_split": 10}},
    {"label": "min_samples_leaf=4", "options": {"min_samples_leaf": 4}},
]

print("\nParameter comparison (accuracy can vary by dataset):")
for setting in settings:
    model = DecisionTreeClassifier(random_state=42, **setting["options"])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"{setting['label']}: {accuracy_score(y_test, predictions):.2f}")

# Print a small readable version of the learned tree rules.
example_tree = DecisionTreeClassifier(criterion="entropy", max_depth=2, random_state=42)
example_tree.fit(X_train, y_train)
print("\nReadable tree rules:\n")
print(export_text(example_tree, feature_names=list(iris.feature_names)))
