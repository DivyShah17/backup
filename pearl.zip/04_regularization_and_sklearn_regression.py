"""Practical 4: Ridge regularization from scratch and with sklearn."""

import numpy as np
from sklearn.linear_model import LinearRegression, Ridge


def ridge_from_scratch(X, y, regularization_strength=1.0):
    """Ridge normal equation; the intercept is not penalized."""
    X_with_intercept = np.c_[np.ones(len(X)), X]
    identity = np.eye(X_with_intercept.shape[1])
    identity[0, 0] = 0  # Do not shrink the intercept.
    weights = np.linalg.pinv(
        X_with_intercept.T @ X_with_intercept + regularization_strength * identity
    ) @ X_with_intercept.T @ y
    return weights


def compare_models(name, X, y):
    # Ordinary (unregularized) linear regression in sklearn.
    plain_model = LinearRegression()
    plain_model.fit(X, y)

    # Ridge is linear regression with an L2 penalty on the coefficients.
    ridge_model = Ridge(alpha=1.0)
    ridge_model.fit(X, y)

    # Same Ridge idea, written directly with NumPy rather than sklearn.
    manual_weights = ridge_from_scratch(X, y, regularization_strength=1.0)

    print(f"\n{name}")
    print("sklearn LinearRegression coefficients:", np.round(plain_model.coef_, 2))
    print("sklearn Ridge coefficients:           ", np.round(ridge_model.coef_, 2))
    print("NumPy Ridge coefficients (intercept first):", np.round(manual_weights, 2))
    print("LinearRegression predictions:", np.round(plain_model.predict(X), 1))
    print("Ridge predictions:           ", np.round(ridge_model.predict(X), 1))


# Simple regression: one feature.
hours = np.array([[1], [2], [3], [4], [5]], dtype=float)
scores = np.array([35, 40, 50, 55, 65], dtype=float)
compare_models("Simple regression", hours, scores)

# Multiple regression: two features.
features = np.array([
    [1, 0],
    [2, 1],
    [3, 1],
    [4, 2],
    [5, 3],
], dtype=float)
scores = np.array([35, 43, 48, 60, 70], dtype=float)
compare_models("Multiple regression", features, scores)
