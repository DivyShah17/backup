"""Practical 9: build XOR from perceptrons trained with PLA.

One perceptron cannot learn XOR because XOR is not separable by one straight
line. Here PLA trains three small perceptrons for OR, NAND, and AND. Connecting
them gives XOR = AND(OR(x1, x2), NAND(x1, x2)). No ML library is used.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])


def train_perceptron(inputs, targets, learning_rate=0.1, max_epochs=100):
    """Train one threshold neuron with the Perceptron Learning Algorithm."""
    weights = np.zeros(inputs.shape[1])
    bias = 0.0

    for _ in range(max_epochs):
        mistakes = 0

        for row, target in zip(inputs, targets):
            total = np.dot(row, weights) + bias
            prediction = 1 if total >= 0 else 0
            error = target - prediction

            if error != 0:
                weights = weights + learning_rate * error * row
                bias = bias + learning_rate * error
                mistakes += 1

        if mistakes == 0:
            break

    return weights, bias


def predict_perceptron(inputs, weights, bias):
    """Return the 0/1 outputs from one trained perceptron."""
    outputs = []
    for row in inputs:
        total = np.dot(row, weights) + bias
        outputs.append(1 if total >= 0 else 0)
    return np.array(outputs)


# Train the two hidden perceptrons.
or_targets = np.array([0, 1, 1, 1])
nand_targets = np.array([1, 1, 1, 0])
or_weights, or_bias = train_perceptron(X, or_targets)
nand_weights, nand_bias = train_perceptron(X, nand_targets)

# Their outputs become the two inputs to a third perceptron.
hidden_outputs = np.c_[
    predict_perceptron(X, or_weights, or_bias),
    predict_perceptron(X, nand_weights, nand_bias),
]
xor_targets = np.array([0, 1, 1, 0])
and_weights, and_bias = train_perceptron(hidden_outputs, xor_targets)
xor_predictions = predict_perceptron(hidden_outputs, and_weights, and_bias)

answer_table = pd.DataFrame({
    "Input 1": X[:, 0],
    "Input 2": X[:, 1],
    "OR hidden output": hidden_outputs[:, 0],
    "NAND hidden output": hidden_outputs[:, 1],
    "Expected XOR": xor_targets,
    "Network output": xor_predictions,
})

print("OR perceptron weights and bias:", or_weights, or_bias)
print("NAND perceptron weights and bias:", nand_weights, nand_bias)
print("AND output perceptron weights and bias:", and_weights, and_bias)
print("\nXOR truth table:")
print(answer_table)

plt.scatter(X[:, 0], X[:, 1], c=xor_targets, cmap="coolwarm", s=160)
for row, label in zip(X, xor_targets):
    plt.annotate(str(label), (row[0] + 0.04, row[1] + 0.04))
plt.xticks([0, 1])
plt.yticks([0, 1])
plt.xlabel("Input 1")
plt.ylabel("Input 2")
plt.title("XOR outputs from a small network of PLA perceptrons")
plt.show()
