# Basic Dataset Operations for an ML Lab

Assume your dataset is in a Pandas DataFrame called \`df\`.

## 1. Load a dataset

\`\`\`python
import pandas as pd

df = pd.read_csv("data.csv")
# Excel option: df = pd.read_excel("data.xlsx")
\`\`\`

## 2. Inspect the data

\`\`\`python
df.head()                 # first 5 rows
df.tail()                 # last 5 rows
df.shape                  # (number of rows, number of columns)
df.columns                # column names
df.info()                 # data types and non-missing counts
df.describe()             # summary of numeric columns
df.isnull().sum()         # missing values in each column
df["Class"].value_counts()  # count each class label
\`\`\`

## 3. Select, filter, and sort rows

\`\`\`python
df["Age"]                         # one column
df[["Age", "Marks"]]              # multiple columns
df.loc[0, "Age"]                  # by row/column labels
df.iloc[0:5, 0:3]                 # by row/column positions
df[df["Marks"] >= 70]             # filter rows
df.sort_values("Marks", ascending=False)  # sort high to low
\`\`\`

## 4. Handle missing values and duplicate rows

\`\`\`python
df = df.drop_duplicates()  # remove exact duplicate rows

# Fill a number column using its average:
df["Age"] = df["Age"].fillna(df["Age"].mean())

# Fill a category/text column using its most common value:
df["City"] = df["City"].fillna(df["City"].mode()[0])

# Alternative: remove rows that contain any missing value.
# Use this only when dropping those rows makes sense for your task:
# df = df.dropna()
\`\`\`

## 5. Create, rename, or remove columns

\`\`\`python
df["Total"] = df["Maths"] + df["Science"]
df = df.rename(columns={"old_name": "new_name"})
df = df.drop(columns=["unneeded_column"])
\`\`\`

## 6. Convert category columns to numbers

Many models require numeric inputs. For categories without a meaningful order, one-hot encoding is usually suitable:

\`\`\`python
df = pd.get_dummies(df, columns=["City"], drop_first=True)
\`\`\`

If a column has an actual order (such as low, medium, high), map it in that order rather than assigning arbitrary numbers to unordered categories.

## 7. Separate features and target

The target is the answer you want the model to predict. Keep it out of the input features:

\`\`\`python
X = df.drop(columns=["Passed"])  # inputs/features
y = df["Passed"]                 # target/answer
\`\`\`

## 8. Split into training and test data

\`\`\`python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)
\`\`\`

For a classification task, add \`stratify=y\` when each class has enough examples:

\`\`\`python
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
\`\`\`

## 9. Scale numeric features without data leakage

Split first. Fit the scaler on training data only, then use that same scaler on the test data:

\`\`\`python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
\`\`\`

The scaler learns the training data's mean and standard deviation. Fitting it on the test data too would let information from the test set affect preprocessing.

## 10. Save the cleaned data

\`\`\`python
df.to_csv("cleaned_data.csv", index=False)
\`\`\`

## A simple exam workflow

1. Load the dataset.
2. Inspect its size, columns, data types, and missing values.
3. Clean missing and duplicate rows.
4. Convert text categories to numeric values if needed.
5. Separate \`X\` (features) and \`y\` (target).
6. Split into training and test data.
7. Scale features if the model needs it.
8. Fit the model, predict on test data, and evaluate.
