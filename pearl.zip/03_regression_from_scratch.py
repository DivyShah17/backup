"""Practical 3: linear regression with no sklearn.

The same small functions work for one input feature (simple regression) or
more than one input feature (multiple regression).
"""

import numpy as np


def add_intercept(X):
    """Add a first column of 1s so the model can learn an intercept."""
    return np.c_[np.ones(len(X)), X]


def gradient_descent(X, y, learning_rate=0.03, epochs=5000):
    """Learn coefficients by repeatedly reducing the mean squared error."""
    X_with_intercept = add_intercept(X)
    weights = np.zeros(X_with_intercept.shape[1])
    number_of_rows = len(y)

    for _ in range(epochs):
        predictions = X_with_intercept @ weights
        errors = predictions - y
        gradient = (2 / number_of_rows) * (X_with_intercept.T @ errors)
        weights = weights - learning_rate * gradient

    return weights


def normal_equation(X, y):
    """Find coefficients directly using the normal equation."""
    X_with_intercept = add_intercept(X)
    # The pseudo-inverse also works when the matrix cannot be inverted directly.
    return np.linalg.pinv(X_with_intercept.T @ X_with_intercept) @ X_with_intercept.T @ y


def show_result(name, X, y):
    gd_weights = gradient_descent(X, y)
    normal_weights = normal_equation(X, y)
    X_with_intercept = add_intercept(X)

    print(f"\n{name}")
    print("Gradient descent coefficients:", np.round(gd_weights, 2))
    print("Normal equation coefficients: ", np.round(normal_weights, 2))
    print("Gradient descent predictions:", np.round(X_with_intercept @ gd_weights, 1))
    print("Normal equation predictions: ", np.round(X_with_intercept @ normal_weights, 1))


# One column in X: simple linear regression.
study_hours = np.array([[1], [2], [3], [4], [5]], dtype=float)
exam_score = np.array([35, 40, 50, 55, 65], dtype=float)
show_result("Simple linear regression", study_hours, exam_score)

# Two columns in X: multiple linear regression.
# Column 1 is study hours; column 2 is practice tests completed.
features = np.array([
    [1, 0],
    [2, 1],
    [3, 1],
    [4, 2],
    [5, 3],
], dtype=float)
scores = np.array([35, 43, 48, 60, 70], dtype=float)
show_result("Multiple linear regression", features, scores)
