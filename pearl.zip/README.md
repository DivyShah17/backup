# Machine Learning Practicals - Easy Python Examples

These examples follow the 10 practicals in the course List of Practicals. Each practical is a separate, small Python file so you can study and run them one at a time. The examples use tiny built-in or hand-written datasets; no dataset downloads are needed.

## Getting started

Install Python 3, then install the packages used by most examples:

\`\`\`bash
python -m pip install numpy pandas matplotlib scikit-learn
\`\`\`

Run a file from this folder, for example:

\`\`\`bash
python 03_regression_from_scratch.py
\`\`\`

The OCR practical needs extra setup. Install its Python packages with:

\`\`\`bash
python -m pip install pytesseract pillow pdf2image
\`\`\`

You also need the Tesseract OCR application installed on your computer. For PDF pages, \`pdf2image\` also needs Poppler. Put your own image and PDF beside the script, then change \`sample.png\` and \`sample.pdf\` to their filenames. Windows users may need to set \`pytesseract.pytesseract.tesseract_cmd\` and pass the Poppler \`poppler_path\` to \`convert_from_path\`.

## Practical index

1. \`01_python_libraries.py\` - Python, NumPy, Pandas, Matplotlib, and scikit-learn basics.
2. \`02_ocr_image_and_pdf.py\` - OCR from one image and every page of a PDF.
3. \`03_regression_from_scratch.py\` - Simple and multiple linear regression with gradient descent and the normal equation, without scikit-learn.
4. \`04_regularization_and_sklearn_regression.py\` - Ridge regression from scratch, then simple/multiple regression with scikit-learn.
5. \`05_naive_bayes.py\` - Bernoulli, Multinomial, and Gaussian Naive Bayes.
6. \`06_decision_trees.py\` - Entropy and Gini decision trees and a small parameter comparison.
7. \`07_svm_grid_search_and_3d_plot.py\` - SVC and SVR with grid search; a 3D view of the SVC decision function.
8. \`08_and_perceptron_from_scratch.py\` - AND gate trained using the Perceptron Learning Algorithm (PLA).
9. \`09_xor_perceptrons_from_scratch.py\` - XOR made from three small perceptrons, each trained using PLA.
10. \`10_mlp_and_kmeans_sklearn.py\` - Neural network classification and K-means with scikit-learn.

## Two details to remember

- A single perceptron draws one straight decision boundary, so it cannot learn XOR. Practical 9 uses a tiny network: PLA trains perceptrons for OR and NAND, then another for AND. Together they compute XOR, with no machine-learning library.
- Scikit-learn's \`DecisionTreeClassifier\` can use \`entropy\` or \`gini\`. Entropy is useful for an ID3-style comparison, while Gini is commonly associated with CART. Scikit-learn's tree implementation makes binary splits, so \`criterion="entropy"\` is not a literal implementation of the original ID3 algorithm.

## Exam practice tip

For each file, first read the short comments, then try to explain the input (\`X\`), answer (\`y\`), model, and prediction in your own words. After that, change one value such as the learning rate, tree depth, or number of clusters and observe what changes.

## Bonus reference

dataset_operations_quick_reference.md contains copy-and-paste examples for loading, inspecting, cleaning, filtering, encoding, splitting, scaling, and saving a dataset.
