"""Bonus: basic dataset operations commonly used in ML lab practicals.

This file runs with the small example data below. To use your own CSV, replace
the sample DataFrame with: df = pd.read_csv("your_file.csv")
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# Load a CSV file like this when you have your own dataset:
# df = pd.read_csv("your_file.csv")

# Small example dataset, so this file can be run without an external data file.
df = pd.DataFrame({
    "Name": ["Asha", "Ravi", "Meera", "John", "Sara", "Dev", "Nina", "Ali", "Maya", "Asha"],
    "Age": [20, 21, 22, 19, None, 23, 24, 21, 20, 20],
    "Marks": [80, 65, 85, 55, 70, 92, 60, 78, 50, 80],
    "City": ["Pune", "Delhi", "Pune", "Mumbai", "Delhi", "Mumbai", "Pune", "Delhi", "Mumbai", "Pune"],
    "Passed": [1, 0, 1, 0, 0, 1, 0, 1, 0, 1],
})

print("First five rows:")
print(df.head())

print("\nNumber of rows and columns:", df.shape)
print("\nColumn names:", list(df.columns))
print("\nData types and missing-value counts:")
df.info()
print(df.isnull().sum())
print("\nSummary of numeric columns:")
print(df.describe())

# Remove exact duplicate rows.
clean_df = df.drop_duplicates().copy()

# Fill missing numeric values with the column mean.
clean_df["Age"] = clean_df["Age"].fillna(clean_df["Age"].mean())

# Fill missing text/category values with the most common value.
clean_df["City"] = clean_df["City"].fillna(clean_df["City"].mode()[0])

print("\nRows after removing duplicates and filling missing values:")
print(clean_df)

# Filter rows: keep people with marks of at least 70.
high_marks = clean_df[clean_df["Marks"] >= 70]
print("\nRows with Marks >= 70:")
print(high_marks)

# Sort by marks, highest first.
sorted_df = clean_df.sort_values(by="Marks", ascending=False)
print("\nSorted by Marks:")
print(sorted_df[["Name", "Marks"]])

# Separate input columns (X) from the answer column (y).
X = clean_df.drop(columns=["Name", "Passed"])
y = clean_df["Passed"]

# Convert text categories into numeric columns.
# drop_first=True avoids keeping a redundant column for every category.
X = pd.get_dummies(X, columns=["City"], drop_first=True)

# Split into training data and test data before scaling.
# stratify=y keeps a similar class balance in both parts.
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.25,
    random_state=42,
    stratify=y,
)

# Learn scaling values using training data only, then apply them to both sets.
# This avoids letting test data influence preprocessing.
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print("\nFeature columns after encoding:", list(X.columns))
print("Training features shape:", X_train_scaled.shape)
print("Testing features shape:", X_test_scaled.shape)
print("Training labels shape:", y_train.shape)
print("Testing labels shape:", y_test.shape)

# Save cleaned data if you want a new CSV file:
# clean_df.to_csv("cleaned_dataset.csv", index=False)
