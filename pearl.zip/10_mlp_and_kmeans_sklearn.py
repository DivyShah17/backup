"""Practical 10: an sklearn neural network and K-means clustering."""

import matplotlib.pyplot as plt
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.cluster import KMeans


# ---------------- Backpropagation neural network ----------------
# MLPClassifier trains its network using backpropagation.
X, y = make_moons(n_samples=120, noise=0.15, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

neural_network = make_pipeline(
    StandardScaler(),
    MLPClassifier(
        hidden_layer_sizes=(8,),
        max_iter=2000,
        random_state=42,
    ),
)
neural_network.fit(X_train, y_train)
predictions = neural_network.predict(X_test)
print("Neural network test accuracy:", round(accuracy_score(y_test, predictions), 2))
print("Prediction for first test row:", predictions[0])

# ---------------- K-means clustering ----------------
# These points visibly form two groups; K-means will find their centers.
points = [
    [1, 1], [1.5, 2], [2, 1.5], [2, 2],
    [7, 7], [8, 7], [7.5, 8], [8, 8],
]

kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(points)
print("\nK-means cluster labels:", cluster_labels)
print("Cluster centers:\n", kmeans.cluster_centers_)

points_x = [row[0] for row in points]
points_y = [row[1] for row in points]
plt.scatter(points_x, points_y, c=cluster_labels, cmap="viridis", s=100)
plt.scatter(
    kmeans.cluster_centers_[:, 0],
    kmeans.cluster_centers_[:, 1],
    color="red",
    marker="X",
    s=200,
    label="Cluster centers",
)
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("K-means with two clusters")
plt.legend()
plt.show()
