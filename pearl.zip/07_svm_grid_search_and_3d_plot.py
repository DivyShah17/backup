"""Practical 7: SVC/SVR grid search and a 3D SVC decision-function plot."""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification, make_regression
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from sklearn.metrics import accuracy_score, r2_score


# ---------------- Support Vector Classification (SVC) ----------------
# Use two features so the decision boundary can be shown on a plot.
X, y = make_classification(
    n_samples=100,
    n_features=2,
    n_redundant=0,
    n_informative=2,
    n_clusters_per_class=1,
    class_sep=1.5,
    random_state=42,
)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# Scaling helps SVM because it compares distances between feature values.
svc_pipeline = make_pipeline(StandardScaler(), SVC(kernel="linear"))
svc_search = GridSearchCV(
    svc_pipeline,
    param_grid={"svc__C": [0.1, 1, 10]},
    cv=3,
)
svc_search.fit(X_train, y_train)
best_svc = svc_search.best_estimator_
class_predictions = best_svc.predict(X_test)
print("SVC best settings:", svc_search.best_params_)
print("SVC test accuracy:", round(accuracy_score(y_test, class_predictions), 2))

# Plot x1, x2, and the SVC decision score as the z-axis.
# The separating hyperplane is the zero level of the decision score.
x1_values = np.linspace(X[:, 0].min() - 0.5, X[:, 0].max() + 0.5, 30)
x2_values = np.linspace(X[:, 1].min() - 0.5, X[:, 1].max() + 0.5, 30)
x1_grid, x2_grid = np.meshgrid(x1_values, x2_values)
grid_points = np.c_[x1_grid.ravel(), x2_grid.ravel()]
scores = best_svc.decision_function(grid_points).reshape(x1_grid.shape)

figure = plt.figure()
axis = figure.add_subplot(111, projection="3d")
axis.plot_surface(x1_grid, x2_grid, scores, alpha=0.45, cmap="coolwarm")
axis.scatter(X[:, 0], X[:, 1], best_svc.decision_function(X), c=y, cmap="coolwarm")
axis.set_xlabel("Feature 1")
axis.set_ylabel("Feature 2")
axis.set_zlabel("Decision score")
axis.set_title("SVC decision function; boundary is score = 0")
plt.show()

# ---------------- Support Vector Regression (SVR) ----------------
X_regression, y_regression = make_regression(
    n_samples=100, n_features=2, noise=15, random_state=42
)
X_train, X_test, y_train, y_test = train_test_split(
    X_regression, y_regression, test_size=0.25, random_state=42
)

svr_pipeline = make_pipeline(StandardScaler(), SVR(kernel="rbf"))
svr_search = GridSearchCV(
    svr_pipeline,
    param_grid={
        "svr__C": [1, 10, 100],
        "svr__epsilon": [0.1, 1.0],
        "svr__gamma": ["scale", 0.1],
    },
    cv=3,
)
svr_search.fit(X_train, y_train)
regression_predictions = svr_search.best_estimator_.predict(X_test)
print("\nSVR best settings:", svr_search.best_params_)
print("SVR test R-squared:", round(r2_score(y_test, regression_predictions), 2))
