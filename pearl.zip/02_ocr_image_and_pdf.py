"""Practical 2: read text from an image and each page of a PDF with OCR.

Install pytesseract, pillow, and pdf2image, plus the Tesseract application.
For PDF conversion, install Poppler too. See README.md for setup notes.
"""

from PIL import Image
import pytesseract
from pdf2image import convert_from_path


# If Tesseract is not on PATH on Windows, uncomment and edit this line:
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

image_path = "sample.png"  # Change this to your image filename.
pdf_path = "sample.pdf"    # Change this to your PDF filename.

# OCR from one image.
image = Image.open(image_path)
image_text = pytesseract.image_to_string(image)
print("TEXT FROM IMAGE")
print(image_text)

# Convert every PDF page to an image, then OCR each image.
# If Poppler is not on PATH on Windows, add: poppler_path=r"C:\path\to\poppler\Library\bin"
pages = convert_from_path(pdf_path, dpi=200)

print("\nTEXT FROM PDF")
for page_number, page_image in enumerate(pages, start=1):
    page_text = pytesseract.image_to_string(page_image)
    print(f"\n--- Page {page_number} ---")
    print(page_text)
